var langs =
[['Dansk',           ['da-DK']],
 ['Deutsch',         ['de-DE']],
 ['English',         ['en-AU', 'Australia'],
                     ['en-CA', 'Canada'],
                     ['en-IN', 'India'],
                     ['en-NZ', 'New Zealand'],
                     ['en-ZA', 'South Africa'],
                     ['en-GB', 'United Kingdom'],
                     ['en-US', 'United States']],
 ['Español',         ['es-AR', 'Argentina'],
                     ['es-BO', 'Bolivia'],
                     ['es-CL', 'Chile'],
                     ['es-CO', 'Colombia'],
                     ['es-CR', 'Costa Rica'],
                     ['es-EC', 'Ecuador'],
                     ['es-SV', 'El Salvador'],
                     ['es-ES', 'España'],
                     ['es-US', 'Estados Unidos'],
                     ['es-GT', 'Guatemala'],
                     ['es-HN', 'Honduras'],
                     ['es-MX', 'México'],
                     ['es-NI', 'Nicaragua'],
                     ['es-PA', 'Panamá'],
                     ['es-PY', 'Paraguay'],
                     ['es-PE', 'Perú'],
                     ['es-PR', 'Puerto Rico'],
                     ['es-DO', 'República Dominicana'],
                     ['es-UY', 'Uruguay'],
                     ['es-VE', 'Venezuela']],
 ['Français',        ['fr-FR']],
 ['Norsk bokmål',    ['nb-NO']],
 ['Svenska',         ['sv-SE']]];

for (var i = 0; i < langs.length; i++) {
  select_language.options[i] = new Option(langs[i][0], i);
}
select_language.selectedIndex = 2;
updateCountry();
select_dialect.selectedIndex = 5;
showInfo('info_start');

function updateCountry() {
  for (var i = select_dialect.options.length - 1; i >= 0; i--) {
    select_dialect.remove(i);
  }
  var list = langs[select_language.selectedIndex];
  for (var i = 1; i < list.length; i++) {
    select_dialect.options.add(new Option(list[i][1], list[i][0]));
  }
  select_dialect.style.visibility = list[1].length == 1 ? 'hidden' : 'visible';
}

var create_email = false;
var final_transcript = '';
var recognizing = false;
var ignore_onend;
var start_timestamp;


if (!('webkitSpeechRecognition' in window)) {

  upgrade();

} else {

  start_button.style.display = 'inline-block';

  var recognition = new webkitSpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;

  recognition.onstart = function()
  {
    recognizing = true;
    showInfo('info_speak_now');
    start_img.src = 'img/mic-animate.gif';
  };

  recognition.onerror = function(event)
  {
    if (event.error == 'no-speech') {
      start_img.src = 'img/mic.gif';
      showInfo('info_no_speech');
      ignore_onend = true;
    }
    if (event.error == 'audio-capture') {
      start_img.src = 'img/mic.gif';
      showInfo('info_no_microphone');
      ignore_onend = true;
    }
    if (event.error == 'not-allowed') {
      if (event.timeStamp - start_timestamp < 100) {
        showInfo('info_blocked');
      } else {
        showInfo('info_denied');
      }
      ignore_onend = true;
    }
  };

  recognition.onend = function()
  {

    recognizing = false;
    if (ignore_onend) {
      return;
    }
    start_img.src = 'img/mic.gif';
    if (!final_transcript) {
      showInfo('info_start');
      return;
    }else{
      // next recording
      //setTimeout(simulateClickOnMic, 2000);
    }
    showInfo('');
    if (window.getSelection) {
      window.getSelection().removeAllRanges();
      var range = document.createRange();
      range.selectNode(document.getElementById('final_span'));
      window.getSelection().addRange(range);
    }
    if (create_email) {
      create_email = false;
      createEmail();
    }

  };

  recognition.onresult = function(event) {
    var interim_transcript = '';
    for (var i = event.resultIndex; i < event.results.length; ++i) {
      if (event.results[i].isFinal) {
        final_transcript += event.results[i][0].transcript;

        // send to giphy
        sentence=final_transcript;
        //chunks(sentence);
        console.log( sentence );
        translateSentence(sentence);

      } else {
        interim_transcript += event.results[i][0].transcript;
      }
    }
    final_transcript = capitalize(final_transcript);
    final_span.innerHTML = linebreak(final_transcript);
    interim_span.innerHTML = linebreak(interim_transcript);
    if (final_transcript || interim_transcript) {
      showButtons('inline-block');
    }
  };
}

function upgrade() {
  start_button.style.visibility = 'hidden';
  showInfo('info_upgrade');
}

// Giphy stuff

var images = [];
var sentenceLength;
var count = 0;

// -- For data save to mlab
var spics = [];
var sdate = "";

function updatePercentage() {
    var percentaile = 100 / sentenceLength;
    $("#percent").width(count * percentaile + "%");
}

function addToPage(uri, term, i, width) {

    // Fill up pics object to save later
    spics.push(
      {
        "term": term,
        "url": uri,
        "width": width
      }
    );

    var image = "<div class='gif' style='width: " + width + "px;background-image: url(" + uri + ");'><span>#" + term + "</span></div>";
    images[i] = image;
    count++;
}

function addzero( dd ) {
  if( dd < 10 ){
    return '0' + dd;
  }
  return dd;
}

function makeSticker(){
  var d = new Date();

  sdate = addzero(d.getHours()) + ':' + addzero(d.getMinutes()) + ' - ' + addzero(d.getDate()) + '.' + addzero(d.getMonth()) + '.' + d.getFullYear();

  var html = '<div class="sticker">';
  html += '<h3>Trailerpark Festival</h3>';

  html += '<p>' + sdate + '</p>';
  html += '</div>';
  return html;
}


function renderPage() {
    var page = images.join(" ");
    $("#interim").remove();
    var sticker = makeSticker();
    $("#app").append( sticker );
    $("#app").append(page);
    //$(".goAgain").show();

    // save data
    saveData();

    // empty sdate & spics
    sdate = "";
    spics = [];
}




function msgToPage(msg){
    $('body').html("<div id='interim'><h5>" + msg + "</h5></div>");
}

function getGif(item, i, array) {

    var xhr = $.get("http://api.giphy.com/v1/gifs/translate",
      {
        api_key: "dc6zaTOxFJmzC",
        s: item,
        limit: 1
      });

    xhr.done(function(msg){
        if (msg.data.length === 0) {
            // deal with null results
            return;
        }

        addToPage(msg.data.images.fixed_height_downsampled.url, item, i, msg.data.images.fixed_height_downsampled.width);

        if (count === array.length) {
            renderPage();
        }
    });
    xhr.error(function(event){
        msgToPage("Something went wrong!");
    });

}

// Google Translate
function translateSentence( sentence ) {

  // check lang for testing purpose
  var lg = select_dialect.value;
  console.log(lg);
  if( lg.indexOf("-")!=-1 ){
    lg = lg.split('-')[0];
  }
  console.log(lg);

  var xhr = $.get( "https://www.googleapis.com/language/translate/v2",
    {
      key: "AIzaSyBVkD7TiAwJrnYTutqKE5xYc5JxiywyNDk",
      source: lg,
      target: "en",
      q: sentence
    });

  xhr.done(function( response ){

    console.log( response.data.translations );

    if( response.data.translations.length > 0 ) {
        chunks( response.data.translations[0].translatedText );
    }



  });
  xhr.error(function(event){
      msgToPage("Something went wrong!");
  });

}

// Pre processing of the sentence
function chunks( transcript ) {
    count = 0;
    var words = transcript.split(/\s/);
    sentenceLength = words.length;
    words.forEach(getGif);

    // next recording
    // setTimeout(simulateClickOnMic, 2000);
}



//

var two_line = /\n\n/g;
var one_line = /\n/g;
function linebreak(s) {
  return s.replace(two_line, '<p></p>').replace(one_line, '<br>');
}

var first_char = /\S/;
function capitalize(s) {
  return s.replace(first_char, function(m) { return m.toUpperCase(); });
}

// Buttons events

function createEmail() {
  var n = final_transcript.indexOf('\n');
  if (n < 0 || n >= 80) {
    n = 40 + final_transcript.substring(40).indexOf(' ');
  }
  var subject = encodeURI(final_transcript.substring(0, n));
  var body = encodeURI(final_transcript.substring(n + 1));
  // window.location.href = 'mailto:?subject=' + subject + '&body=' + body;
}

function copyButton() {
  if (recognizing) {
    recognizing = false;
    recognition.stop();
  }
  copy_button.style.display = 'none';
  copy_info.style.display = 'inline-block';
  showInfo('');
}

function emailButton() {
  // if (recognizing) {
  //   create_email = true;
  //   recognizing = false;
  //   recognition.stop();
  // } else {
  //   createEmail();
  // }
  // email_button.style.display = 'none';
  // email_info.style.display = 'inline-block';
  // showInfo('');
}


function simulateClickOnMic() {
  var evt = document.createEvent("MouseEvents");
  evt.initMouseEvent("click", true, true, window,
    0, 0, 0, 0, 0, false, false, false, false, 0, null);
  var a = document.getElementById("start_button");
  a.dispatchEvent(evt);
}

// Automatic start
// setTimeout(simulateClickOnMic, 3000);

function startButton(event) {
  if (recognizing) {
    recognition.stop();
    return;
  }
  final_transcript = '';
  recognition.lang = select_dialect.value;
  recognition.start();
  ignore_onend = false;
  final_span.innerHTML = '';
  interim_span.innerHTML = '';
  start_img.src = 'img/mic-slash.gif';
  showInfo('info_allow');
  showButtons('none');
  start_timestamp = event.timeStamp;
}

function showInfo(s) {
  if (s) {
    for (var child = info.firstChild; child; child = child.nextSibling) {
      if (child.style) {
        child.style.display = child.id == s ? 'inline' : 'none';
      }
    }
    info.style.visibility = 'visible';
  } else {
    info.style.visibility = 'hidden';
  }
}

var current_style;
function showButtons(style) {
  if (style == current_style) {
    return;
  }
  current_style = style;
  // email_button.style.display = style;
  // email_info.style.display = 'none';
}

////////// Mlab - Mongo Database save
// Save datetime, word

function saveData() {
  $.ajax( {
    url: "https://api.mlab.com/api/1/databases/trailerparkgiphy/collections/tpgif?apiKey=ZrLeJiw98cvg0X7sXncxKbgMX6u5ox8w",
		data: JSON.stringify( [ {
      "date" : sdate,
      "gifs" : spics
    } ] ),
		type: "POST",
		contentType: "application/json" } );

}
